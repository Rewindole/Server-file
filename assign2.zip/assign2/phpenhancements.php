<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="A web page about XML and SGML">
        <title>Part A Enhancements</title>
        <link rel="stylesheet" href="styles/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    </head>
    
    <body>
        <?php include "menu.inc";?>

        <header>
            <h1>Enhancements</h1>
        </header>
          
        <section>
            <h2>Development Problems</h2>
                <p> Within the added struggle of completing this project with only three group members, we did not have time to sufficiently complete any enhancements.
                    We had planned to enhance the site by reformatting using SASS as a preprocessor, but did not have time in the end. Also, we wanted to add responsiveness to the site, which we could not do due to time constraints as well.
                    The project does have some advanced CSS elements though, so we thought we should share some of these. 
                </p>
            <h2>CSS features</h2>
            <br>
            <h3>Hover Effects</h3>
            <p>One of the main innovative style features would have to be the hover effects on the navigation bar text. This was done to stylise the focused text into the style in which tags are written in markup languages.
                Therefore, this element was not used as random styling within the page, but it had some prior context which made it more important within the relation to content.
                <br>
                You can see it in action here: <a><span class="tag">&lt;</span>Hover me!<span class="tag">&#47;&gt;</span></a>
                <br>
                This element targets the navigation bar elements. This is achieved by assigning a class to a piece of span text that displays &lt; and &#47;&gt; but is solid white until hovered over. 
                This is obviously controlled via css pseudo elements.  
            </p>
            <br>
            <h3>Card elements</h3>
            <p> Another feature of the website would be the implementation of card-like squares of information. These are extremely elegant and deliver content in small sizes whilist looking very neat.
                I achieved this through experimenting with CSS's grid layout. The grid layout allows for precise control over the x and y axis through the use of rows and columns.
                The benefit to this is that it acts as an extension on what CSS flex could've been.
                <br>
                I was originally planning on implementing responsiveness to the website by refactoring all of the website elements to display in grid format. I thought that this would be the best up-to-date example of responsive design. 
                This would've also allowed me to not have to write heaps of media queries etc. 
            </p>

            <div class="learn-grid">
                <aside class="card">
                    <h3><a href="#">Example card</a></h3>
                    <p>These cards are an example of how information is displyed.</p>       
                </aside>
                <aside class="card">
                    <h3><a href="#">Example card</a></h3>  
                    <p>These cards are an example of how information is displyed.</p>      
                </aside>
            </div>
        </section>

        <?php include "footer.inc";?>

    </body>
</html>