
<!-- This page was created by Aston Lynch -->

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">        <meta name="description" content="A web page about XML and SGML">
        <title>XML and SGML</title>
        <link rel="stylesheet" href="styles/style.css">        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">
    </head>
    <body>
        <?php include "menu.inc";?>
        <section class="hero">
            <aside class="hero-elements">
                <h1>XML &<br><span>SGML</span></h1>
                <img src="images/file.png" alt="">
            </aside>
        </section>

        <section>
            <h2>About</h2>
            <p> This webpage is designed to inform anyone about the history and use of both SGML and XML.
                 Information is provided that is clear to follow and you can easily navigate through the site at any point.
            </p>
        </section>

        <section>
            <h2>Preface</h2>
            <p> Within the development of our project, we have had two members stay silent until the last week. It is within this last week that they have sent us what they believe is a 
                fair contribution to the project. In our eyes this is not fair at all, as they didn't even check on what hadn't been done, and instead just made copies of existing pages.
                Below are links to their pages, one of which is an alternate version of the index, and one is apparently an alternate XML topic page, but looks like a direct clone of the existing one.
            </p>
                <h3><a href="index2.html">Abar Hasan's Index Page</a></h3>
                <h3><a href="topic3.html">Faiyaz MD's XML Page</a></h3>
        </section>

        <br>
        <br>

        <section>
            <h2>Video demonstration</h2>
            <p>To watch a video of our website <a href="https://www.youtube.com/watch?v=GtPmas8mcHs">click here</a></p>
        </section>

        <section id="learn">
            <h2>Learn More</h2>
            <p>Use the cards below to find out more about these markup technologies and our website</p> 
            <div class="learn-grid">
                <aside class="card">
                    <h3><a href="topic1.html">XML</a></h3>
                    <p>This page contains information about XML, an extensible markup language that changed the world of computing.</p>       
                </aside>
                <aside class="card">
                    <h3><a href="topic2.html">SGML</a></h3>  
                    <p>This page contains information about SGML, a markup language that was the first of it's kind, and inspired other languages.</p>      
                </aside>
                <aside class="card">
                    <h3><a href="quiz.html">Quiz</a></h3>  
                    <p>Test your knowledge with our quiz module, which asks questions related to the information provided in the topic pages.</p>      
                </aside>
                <aside class="card">
                    <h3><a href="enhancements.html">Enhancements</a></h3> 
                    <p>This page contains information about the developement process of the website, with emphasis on furthering the way our information is displayed.</p>       
                </aside>
            </div>
        </section>
        <?php include "footer.inc";?>
    </body>
</html>