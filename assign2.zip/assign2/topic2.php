
<!-- This page was created in collaboration between Luan and Aston -->

<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Information about SGML" />
        <meta name="keywords" content="HTML5, tags" />
        <meta name="author" content="Luan Nguyen, Aston Lynch"  />

        <link rel="stylesheet" href="styles/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

        <title>SGML</title>
    </head>

    <body>
        <?php include "menu.inc";?> 
        <header>
            <h1>SGML</h1>
        </header>
        
        <section>
            <h2>What is SGML and It's purpose? </h2>
            <p> SGML (Standard Generalized Markup Language) is a markup language that acts as a refinement of GML (Generalized Markup Language) <sup><a href='#footnote-1' id='ref1'>[1]</a></sup>.
                SGML was created in a time when there was no internet yet, hence, the markup language aimed to markup documents, giving meaning to different sections of plaintext using tags <sup><a href='#footnote-2' id='ref2'>[2]</a></sup>
                It is through this development that the language was so easy to read for humans, but not so much for systems, which is ultimately why SGML lost a lot of attention as time progressed.
                SGML is used to specify DTDs (document type definitions). A DTD defines a kind of document and specifies what elements must appear within the document<sup><a href='#footnote-3' id='ref3'>[3]</a></sup>.
                This is then parsed to display text in the same way as we would within HTML, with each element differing in presentation. 
                SGML was important when it was developed as it allowed for the capability to encode full file structures and document content within a non-propriety environment<sup><a href='#footnote-4' id='ref4'>[4]</a></sup>, which encompassed a freer approach to marking up files.        
            </p>
        </section>

        <div>
            <article>
                <h2>Features of SGML</h2>
                <ol>    
                    <li>Boundaries of elements are marked by tags.</li>
                    <li>Elements carry generic type and other attributes.</li>
                    <li>Capable of dealing with any media type or linking protocol.</li>
                </ol>   
            </article>

            <aside class="dataTable">
                <h2>Advantages and Disadvantages of SGML</h2>
                <table>
                    <tr>
                        <th>Advantage of SGML</th>
                        <th>Disadvantages of SGML </th>
                    </tr>
        
                    <tr>
                        <td>Extremely Flexible.</td>
                        <td>SGML is very complex, and easier alternatives have been developed.</td> 
                    </tr>
        
                    <tr>
                        <td>Separates content from appearance.</td>
                        <td>Linking is complex.</td>
                    </tr>
                    
                    <tr>
                        <td>Many tools available due to the language being ISO standard.</td>
                        <td>Tools used in SGML are expansive.</td>
                    </tr>
        
                    <tr>
                        <td>Capable of dealing with any type of media or linking protocols.</td>
                        <td>Special software is required to view SGML files.</td>
                    </tr>
                </table>
            </aside>
        </div>

        <section class="content-development">
            <h2>Who developed SGML? When? why? </h2>
            <p> SGML was developed as an adaptation of IBM's GML, which was developed by Charles Goldfarb, Edward Mosher, and Raymond Lorie in October 1985<sup><a href='#footnote-4' id='ref4'>[4]</a></sup> . After the completion of GML, Goldfarb continued research into document structures and linking features that GML did not have. SGML became a project that streamlined GML into exactly what Goldfarb wanted.
                Goldfarb believed that his ideas to standardize document representation were far superior to any other and so he pushed SGML into becoming the most popular markup language of the time. 
            </p>
            <aside>
                <figure>
                    <a href="http://sgmlsource.com/press/index.htm"><img id="GoldFarb" src="images/GoldFarb.jpg" alt="Charles Goldfarb"></a>
                    <figcaption>Charles Goldfarb: Father of SGML</figcaption>
                </figure>
            </aside>
        </section>
        
        <section class="content-management">
            <h2>Which group is responsible for managing SGML? </h2>
            <p>As SGML aimed to be a standardized version of GML, the Internation Organization for Standardization (ISO) were the larger group in charge of the development and refinement of SGML through it's time<sup><a href='#footnote-5' id='ref5'>[5]</a></sup>.
            </p>
        </section>
        
        <section class="growth">
            <h2>The growth/decline of SGML and it's future. </h2>
            <p> SGML was widely used upon initial release. This popularity saw the technology be implemented in various industries that were using computers at the time. However this was the 80's and early 90's, before there was any alternatives that were widely covered.
                It wasn't until XML was created as a subset of SGML that things changed a lot. SGML became a language that was far too complicated to use in most situations, and the passage of time made SGML fade whilst XML grew in popularity.
                Today, SGML is rarely used, and could mostly be seen on old operations that went dormant. As time progressed, so did technology, and today we have the option to choose from a wide range of different languages for hierarchal file storage.
            </p>
        </section>

        <section class="comparison">
            <h2>Comparison of SGML and XML.</h2>
                    
            <h3>What is XML? </h3>
            <p> XML short for eXtensible Markup Language, is a markup language and file format for storing, transmitting, and reconstructing data. It was developed as a subset of SGML. 
            </p>

            <dl>
                <dt>Similarities</dt>
                    <dd>Both act to allow users to display elements in a hierarchal manner.</dd>
                    <dd>Both use elements and tags as a way to define different segments of data.</dd>
                    <dd>Both can basically do the same thing as XML was derived from SGML.</dd>
                <dt>Differences</dt>
                    <dd>XML is far less complex and achieves everything SGML set out to do using fewer rules.</dd>
                    <dd>XML does not use tools that make authoring difficult or costly.</dd>
            </dl>
        </section>

        <br>
            
        <section>
            <h2>Reference</h2>
            <p>
                <sup id="footnote-1"> [1] SGML. (2019). In A Dictionary of Publishing (1st ed.). Oxford University Press.<a href="https://www.oxfordreference.com/view/10.1093/acref/9780191863592.001.0001/acref-9780191863592-e-215">https://www.oxfordreference.com/view/10.1093/acref/9780191863592.001.0001/acref-9780191863592-e-215</a></sup>
                <br/>
                <sup id="footnote-2"> [2] David Hemmendinger. (2020). SGML. In Britannica Online. Britannica Inc.<a href="https://www.britannica.com/technology/SGML">https://www.britannica.com/technology/SGML</a></sup>
                <br/>
                <sup id="footnote-3"> [3] Auto-Graphic, An Introduction to SGML, Auto-graphics, viewed day 30th of March 2022<a href=" http://xml.coverpages.org/autograp.html"> http://xml.coverpages.org/autograp.html</a> </sup>
                <br>       
                <sup id="footnote-4"> [4] SGML Users' Group. (1990). A Brief History of the Development of SGML Charles F.Goldfarb,<a href="http://www.sgmlsource.com/history/sgmlhist.htm">http://www.sgmlsource.com/history/sgmlhist.htm</a></sup>
                <br/>
                <sup id="footnote-5"> [5] <a href="https://publish.uwo.ca/~dspanner/sgmladv.html" title="website">https://publish.uwo.ca/~dspanner/sgmladv.html</a></sup>
                <br/>
                <sup id="footnote-6"> [6] <a href="https://en.wikipedia.org/wiki/Standard_Generalized_Markup_Language" title="website">https://en.wikipedia.org/wiki/Standard_Generalized_Markup_Language</a></sup>
                <br/>
                <sup id="footnote-7"> [7] <a href="https://www.simonstl.com/articles/lettinggo.htm" title="website">https://www.simonstl.com/articles/lettinggo.htm </a></sup>
            </p> 
        </section>
        
        <?php include "footer.inc";?>
    </body>
</html>