
<!-- This page was created mostly by Dhurv, and edited by Aston -->

<!DOCTYPE html>

<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="Information about XML" />
        <meta name="keywords" content="HTML5, tags" />
        <meta name="author" content="Dhruv Patel"  />

        <link rel="stylesheet" href="styles/style.css">
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Poppins&display=swap" rel="stylesheet">

        <title>XML</title>

    </head>

    <body>
        <?php include "menu.inc";?>
        <header>
            <h1>XML</h1>
        </header>
        
        <section>
            <h2>What is XML and It's purpose? </h2>
            <p> XML (eXtensible Markup language) is a markup language that is similar to HTML. However, HTML presents data to the user using predefined tags. Although, XML is used to represent data, where the user can define their own tags to store, share and search for data. <sup><a href='#footnote-1'>[1]</a></sup> XML is an important language as it allows the creator or any other user to read the information presented in the document as the user-defined tags can be self-explanatory.<sup><a href='#footnote-2'>[2]</a></sup> XML was approved by the World Wide Web Consortium in February 1998, and its purpose was to be capable of general data storage. 
                The major features are, it's extensible' meaning it could have its own defined tags then being limited. It is self-describing, where it is readable by the creator and other users. Another benefit is it can be used to easily exchange data as it has massive support, many vendors support it in some form.<sup><a href='#footnote-3' id='ref3'>[3]</a></sup> Also, XML allows the user to create specialised vocabularies, such as Wireless Application Protocol (WAP), Wireless Markup language (WML), and such. 
            </p>
        </section>

        <div>
            <article>
                <h2>Features of XML</h2>
                <ol>    
                    <li>Human and machine readable.</li>
                    <li>Extensive support by different vendors.</li>
                    <li>Users are not restricted to pre-defined tags.</li>
                </ol>   
            </article>

            <aside class="dataTable">
                <h2>Advantages and Disadvantages of XML</h2>
                <table>
                    <tr>
                        <th class>Advantage of XML</th> 
                        <th class>Disadvantages of XML </th>
                    </tr>
        
                    <tr>
                        <td>XML allows validation through DTD and Schema, and this ensures the file is free of syntex errors.</td>
                        <td>XML's syntax is verbose and redundant compared to other technologies. </td> 
                    </tr>
        
                    <tr>
                        <td>XML is human and machine readable.</td>
                        <td>Lacks support for arrays.</td>
                    </tr>
                    
                    <tr>
                        <td>XML can be used to store binary data, which is done though "Base64".</td>
                        <td>Files are increasingly larger due to verbose nature of the language.</td>
                    </tr>
        
                    <tr>
                        <td>Business can use it to view documents through a browser.</td>
                        <td>XML becomes less readable as the data size grows.</td>
                    </tr>
                </table>
            </aside>
        </div>

        <section class="content-development">
            <h2>Who developed XML? When? why? </h2>
            <p> XML was developed by Jon Bosak, Tim Bray, C.M Sperberg-MCQueen, James Clark and several other who wanted to develop a lite version of SGML which retained’ its power however removed it complexity.<sup><a href='#footnote-4' id='ref4'>[4]</a></sup> It did this by using a similar document defying methods as SGML, known as DTDs (document type definitions)<sup><a href='#footnote-5' id='ref5'>[5]</a></sup>  to define document type and tags. Whilst both use the same method to define documents, XML was developed to simplify it to make parse easier, such as document entities are marked using a beginning and end tag such as 
                XML was completed in February of 1998 and saw instant success with users who required structural markup language but had been hesitant to use SGML. 
            </p>
            <aside>
                <figure>
                    <a href="https://www.legacy.com/ca/obituaries/chroniclejournal/name/john-bosak-obituary?pid=198834518"><img id="basok" src="images/bosak.png" alt="Jon Bosak"></a>
                    <figcaption>Jon Basok: lead in the creation of XML</figcaption>
                </figure>
            </aside>
        </section>
        
        <section class="content-management">
            <h2>Which group is responsible for managing XML? </h2>
            <p>XML is a project of the World Wide Web Consortium, the group responsible for it's development is the XML working Group. Members consists of individuals, co-oped contributors, and experts from different areas of web development.<sup><a href='#footnote-6' id='ref6'>[6]</a></sup> 
            </p>
        </section>
        
        <section class="growth">
            <h2>The growth/decline of XML and it's future. </h2>
            <p> XML grew in popularity during it's launch due to two factors. When released, it was recognised by the W3C, which made vendors feel the necessity to support it in some form. However, the main reason was its ability for platform data exchange for cross-platform. 
                Whilst XML was popular near the early age of the web, it had its flaws however, it was slow when the code required tremendous number of tags, the overall response would be slow.  New alternative was adopted soon in 2001, called JSON (JavaScript Object Notation). 
                XML future whilst not set does look brim due to the acceptance of JSON. However, XML is sticking around still, W3C suggesting XML for purposes like books and invoices.<sup><a href='#footnote-7' id='ref7'>[7]</a></sup> 
            </p>
        </section>

        <section class="comparison">
            <h2>Comparison of XML and JSON.</h2>
                    
            <h3>What is JSON? </h3>
            <p> JSON (JavaScript Object Notation) was developed by Douglas Crockford in the early 2000s. Many web developers started using JSON as it was easier than XML and became a EMCA international standard in 2013. <sup><a href='#footnote-8' id='ref8'>[8]</a></sup> 
            </p>

            <dl>
                <dt>Similarities</dt>
                    <dd>JSON and XML are designed in a way to be both human and machine readable.</dd>
                    <dd>Designed to store and transfer data.</dd>
                    <dd>Both have a Hierarchal approach in their codes, where there are values within values.</dd>
                <dt>Differences</dt>
                    <dd>XML has more verbose and is structured then JSON.</dd>
                    <dd>XML is W3C recommended, whilst JSON is not.</dd>
                    <dd>XML has a far grater data type customisation then JSON, which is far limited in options.</dd>
            </dl>
        </section>

        <br>
            
        <section>
            <h2 id="footnote-label">Reference</h2>
            <p>
                <sup id="footnote-1"> [1] developer.mozilla.org. (n.d.). XML introduction - XML: Extensible Markup Language | MDN. [online] Available at: https://developer.mozilla.org/en-US/docs/Web/XML/XML_introduction. <a href="https://developer.mozilla.org/en-US/docs/Web/XML/XML_introduction" title="Website">https://developer.mozilla.org/en-US/docs/Web/XML/XML_introduction.</a></sup>
                <br/>
                <sup id="footnote-2"> [2] Joshi, B 2017, Beginning XML with C# 7: XML Processing and Data Access for C# Developers, Apress L. P, Berkeley, CA.<a href='https://link.springer.com/book/10.1007/978-1-4842-3105-0' title='Book'></a> </sup>
                <br/>
                <sup id="footnote-3"> [3] XML | Definition & Facts | Britannica. (2019). In: Encyclopædia Britannica. [online] Available at: . <a href="https://www.britannica.com/technology/XML" title="website">https://www.britannica.com/technology/XML</a>  </sup>
                <br/>
                <sup id="footnote-4"> [4] A Brief History of XML 2015, Chris Collins, Chris Collins. <a href="https://ccollins.wordpress.com/2008/03/03/a-brief-history-of-xml/" title="journal">https://ccollins.wordpress.com/2008/03/03/a-brief-history-of-xml/</a>  </sup>
                <br/>
                <sup id="footnote-5"> [5] The XML FAQ n.d., xml.coverpages.org,  <a href="http://xml.coverpages.org/FAQv21-200201.html#:~:text=6%20Who%20is%20responsible%20for,by%20their%20XML%20Working%20Group." title="website"> http://xml.coverpages.org/FAQv21-200201.html#:~:text=6%20Who%20is%20responsible%20for</a> viewed 30 March 2022, </sup>
                <br/>
                <sup id="footnote-6"> [6] Why XML Is So Popular | Why XML? | InformIT n.d., www.informit.com, viewed 30 March 2022,  <a href="https://www.informit.com/articles/article.aspx?p=27284" title="Article">https://www.informit.com/articles/article.aspx?p=27284.</a> </sup>
                <br/>
                <sup id="footnote-7"> [7] desmond (2016). More about the decline of XML. Available at:   <a href="http://digitalvariants.blogspot.com/2016/10/more-about-fall-of-xml.html" title="blogpost">http://digitalvariants.blogspot.com/2016/10/more-about-fall-of-xml.html</a> [Accessed 26 Mar. 2022]. </sup>
                <br/>
                <sup id="footnote-8"> [8] Simmons, TJ 2018, ‘Is XML Dying?’, in TJ Simmons (ed.), Is XML Dying?, 29 May, viewed 27 March 2022,  <a href="https://blog.submain.com/json-and-xml-dying/" title="Blogpost"> https://blog.submain.com/json-and-xml-dying/.</a> </sup>
                <br/>
                <sub id="footnote-9"> [9] JSON vs XML: What’s the Difference? 2019, <a href="https://www.guru99.com/json-vs-xml-difference.html" title="website">https://www.guru99.com/json-vs-xml-difference.html</a>: Similarities and Differences </sub>
            </p> 
        </section>
        
        <?php include "footer.inc";?>

    </body>
</html>